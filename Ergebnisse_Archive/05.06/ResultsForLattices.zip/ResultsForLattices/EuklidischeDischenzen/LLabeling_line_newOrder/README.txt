Neue Nummerirung von Knoten der untersuchten Graphen 
