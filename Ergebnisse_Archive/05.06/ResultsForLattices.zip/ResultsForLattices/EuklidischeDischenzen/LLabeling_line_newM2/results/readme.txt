Lambda in dem Modell wird durch Ergebnis Lambda_disk des klassischen Modells begrenzt:
Lambda_disk <= Lambda <= 3Lambda_disk
M = MAX_INT
