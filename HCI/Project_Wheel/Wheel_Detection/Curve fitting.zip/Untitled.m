%function Untitled()

clear all;
close all;
clc;



% imDir --> using ffmpeg, image directory of one sequence (at 25 fps, ~500 images each)
% imDir = '/home/osuemer/Projects/Fare_tekerlek/data/Maus1/frames_trial_201411111614571/';
% imDir = '/home/osuemer/Projects/Fare_tekerlek/data/Maus1/frames_trial_20141020191115117/';
% imDir = '/home/osuemer/Projects/Fare_tekerlek/data/Maus4/frames_trial_201411122034231/';
 imDir = '/home/osuemer/Projects/Fare_tekerlek/data/Maus5/frames_trial_2014102103300061/';


images = dir([imDir,'*.jpg']);
nFrame = size(images,1);

res = [];


for fr=1:nFrame
    im1 = rgb2gray(imread([imDir, images(fr).name]));

       
    im_t = adapthisteq(im1);
    im_t = imgaussfilt(im_t, 2);
   
    [centers, radii] = imfindcircles(im_t,[10 15],'ObjectPolarity','dark', 'Sensitivity',0.95);
    
    res = [res; centers];
    
    % % To check detections frame by frame
    % if numel(centers)
    %     for p=1:size(centers,1)
    %         im1 = insertShape(im1, 'circle', [centers(p,:), 1], 'LineWidth', 5,'Color','red');
    %     end
    % end
    %f1=imshow(im1);
    % hold on; 
    %f2=imshow(imflow); set(f2, 'AlphaData',0.4);
    %waitforbuttonpress;
    
    
    fprintf('%d ',fr);
end

fprintf('\n ');



A= round(res);
resMat = zeros(640, 1280);
for i=1:size(A,1)
resMat(A(i,2),A(i,1))=resMat(A(i,2),A(i,1))+1;
end

%subplot(2,1,1); f1=imshow(im1); hold on;  f2=imagesc(resMat); set(f2, 'alphadata',0.5); subplot(2,1,2); imshow(im1);

points = res;
save('results/Maus5_2014102103300061_095.mat','points');


